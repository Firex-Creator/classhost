<?php

$con = mysqli_connect("localhost", "root", "", "classhost");

if($con){
    // echo "connection was successful";
}else{
    echo "connection was not successful".mysqli_connect_error($con);
}


?>