<?php

include "connect.php";

// check the request coming from the broswer
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // get the data from the form, i will validate the data
    $user = mysqli_real_escape_string($con, $_POST['user']);
    $pswd = mysqli_real_escape_string($con, $_POST['pswd']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $status = "pending";
    
    // validate email emails
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){

        // check is input is empty
        if(!empty($user) && !empty($pswd) && !empty($email)){
            $check = mysqli_query($con, "SELECT * FROM `user` WHERE `email` = '$email'");
            if(mysqli_num_rows($check) > 0){
                $key = "failed";
                $message = "User already exsit";

            }else{
                $insert = mysqli_query($con, "INSERT INTO `user` (`email`, `username`, `pswd`, `status`) 
                                                            VALUES ('$email', '$user', '$pswd', '$status')");
                if($insert){
                    $key ="success";
                    $message = "User registratio successful";
                }
                

            }
        }else{
            $key = "failed";
            $message = "Hey Buddy enterm your information, don't be lazy";
        }

    }else{
        $key = "failed";
        $message = "Email is invalid";
    }
    echo json_encode(array("key"=>$key, "message"=>$message));
    
}

?>